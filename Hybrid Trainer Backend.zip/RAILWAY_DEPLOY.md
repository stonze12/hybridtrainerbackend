# Deploying to Railway — Step by Step

This assumes you have the `hybrid-trainer-backend` folder from the zip, a Railway account (railway.app, sign up with GitHub is easiest), a Stripe account, and your Anthropic API key.

---

## 1. Get the code into a GitHub repo

Railway deploys from GitHub, not from a zip upload. Push this folder to a new repo:

```bash
cd hybrid-trainer-backend
git init
git add .
git commit -m "Initial backend"
gh repo create hybrid-trainer-api --private --source=. --push
```

(No `gh` CLI? Create an empty repo on github.com first, then `git remote add origin <url>` and `git push -u origin main`.)

`node_modules` and `.env` are already excluded via `.gitignore` — Railway installs dependencies itself and you'll set environment variables through its dashboard, not by committing a `.env` file.

---

## 2. Create the Railway project

1. Go to railway.app → **New Project** → **Deploy from GitHub repo** → pick the repo you just pushed.
2. Railway will detect it's a Node app (via Nixpacks, reading your `package.json`) and start a build automatically. **Let this first deploy fail or sit incomplete** — it has no database, no Redis, and no environment variables yet. That's expected; you're about to add all three.

---

## 3. Add PostgreSQL

1. In your Railway project, click **+ New** → **Database** → **Add PostgreSQL**.
2. Railway provisions it and automatically creates a `DATABASE_URL` variable — but it sets that variable on the *Postgres service itself*, not on your API service. You need to reference it from your API service:
   - Click on your **API service** (not the Postgres one) → **Variables** tab → **+ New Variable** → instead of typing a value, click **Add Reference** → select the Postgres service → choose `DATABASE_URL`.
   - This links the two services so if Railway ever rotates the database credentials, your API automatically gets the updated value without you touching anything.

---

## 4. Add Redis

Same pattern as step 3:

1. **+ New** → **Database** → **Add Redis**.
2. On your API service's **Variables** tab, **Add Reference** → the Redis service → `REDIS_URL`.

---

## 5. Run the database migration

You need `schema.sql` and `credit_functions.sql` applied to the new database once. The easiest way without setting up a separate CI step:

1. On your local machine, install the Railway CLI: `npm install -g @railway/cli`
2. `railway login`
3. `railway link` (select your project when prompted)
4. From inside your project folder, run:
   ```bash
   railway run npm run migrate
   ```
   `railway run` executes the command with all of your Railway project's environment variables injected — including the real `DATABASE_URL` — so `scripts/migrate.js` connects to your actual Railway Postgres instance and creates every table and function from `src/db/`.
5. You should see `✓ schema.sql applied successfully.` and `✓ credit_functions.sql applied successfully.` If you get a permission or connection error here, double check step 3's variable reference actually saved.

---

## 6. Set up Stripe

### 6a. Create your Products and Prices

In the Stripe Dashboard (dashboard.stripe.com → **Product catalog**):

1. Create a product **"Pro Membership"** with a recurring price of **$14.99/month**. Copy the resulting Price ID (starts with `price_`).
2. Create four more products, each with a one-time price, for your credit packs: $4.99, $9.99, $19.99, $49.99. Copy all four Price IDs.

You'll paste these five Price IDs into Railway's environment variables in step 7.

### 6b. Get your secret key

**Developers** → **API keys** → copy your **Secret key** (`sk_test_...` while testing, `sk_live_...` once you're ready for real payments — don't mix them up).

### 6c. Set up the webhook — this part has a chicken-and-egg problem

Stripe needs a live URL to send webhooks to, but you don't have your Railway URL until after your first successful deploy. Order of operations:

1. Skip the webhook for now — come back to this after step 7.

---

## 7. Set the remaining environment variables

Back in Railway, on your API service's **Variables** tab, add each of these (plain key/value, not references this time):

```
JWT_ACCESS_SECRET=<run: openssl rand -hex 64>
JWT_REFRESH_SECRET=<run: openssl rand -hex 64, a DIFFERENT value than above>
ANTHROPIC_API_KEY=<your Anthropic key>
STRIPE_SECRET_KEY=<from step 6b>
STRIPE_WEBHOOK_SECRET=<placeholder for now, e.g. "whsec_pending" — you'll replace this in step 9>
STRIPE_PRICE_PRO_MONTHLY=<from step 6a>
STRIPE_PRICE_PACK_500=<from step 6a>
STRIPE_PRICE_PACK_1200=<from step 6a>
STRIPE_PRICE_PACK_3000=<from step 6a>
STRIPE_PRICE_PACK_10000=<from step 6a>
APP_URL=<your frontend's URL — can be a placeholder for now if you haven't deployed the frontend yet>
ALLOWED_ORIGINS=<your frontend's URL, same as above>
```

Run `openssl rand -hex 64` twice on your own machine's terminal (Mac/Linux have this built in) to generate the two JWT secrets — don't reuse the same string for both.

Railway will automatically redeploy your service every time you save new variables.

---

## 8. Get your live URL and verify it's working

1. On your API service, go to **Settings** → **Networking** → **Generate Domain**. Railway gives you a free `*.up.railway.app` URL.
2. Visit `https://your-app-name.up.railway.app/health` in a browser. You should see:
   ```json
   {"status":"ok","timestamp":"..."}
   ```
   If you see an error instead, click into the **Deployments** tab and check the build/deploy logs — the most common issues at this stage are a missing environment variable (the server is built to crash immediately with a clear message naming exactly which one is missing) or the database migration from step 5 not having run yet.

---

## 9. Finish the Stripe webhook setup

Now that you have a real URL:

1. Stripe Dashboard → **Developers** → **Webhooks** → **Add endpoint**.
2. Endpoint URL: `https://your-app-name.up.railway.app/api/webhooks/stripe`
3. Select events to listen for: `checkout.session.completed`, `invoice.payment_succeeded`, `invoice.payment_failed`, `customer.subscription.updated`, `customer.subscription.deleted`, `charge.refunded`.
4. After creating it, Stripe shows you a **Signing secret** (starts with `whsec_`). Copy it.
5. Back in Railway, update the `STRIPE_WEBHOOK_SECRET` variable with this real value (replacing the placeholder from step 7).

---

## 10. Test the whole thing end to end

```bash
# Register a user
curl -X POST https://your-app-name.up.railway.app/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email":"you@example.com","username":"testuser","password":"SomethingSecure123"}'

# Log in
curl -X POST https://your-app-name.up.railway.app/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"you@example.com","password":"SomethingSecure123"}'
```

The login response includes an `accessToken`. Use it to check your profile:

```bash
curl https://your-app-name.up.railway.app/api/users/me \
  -H "Authorization: Bearer <paste accessToken here>"
```

You should see your new account with **25 credits** (the signup bonus) and `membership_type: "free"`.

For testing Stripe payments without using a real card, use Stripe's test card number `4242 4242 4242 4242` with any future expiry date and any CVC, while `STRIPE_SECRET_KEY` is still your `sk_test_...` key.

---

## What's still on you before this is a real, public product

- **Switch Stripe from test mode to live mode** (`sk_live_...` key, live webhook endpoint, live Price IDs) only once you've actually tested the full purchase flow in test mode.
- **Point a real domain** at Railway instead of the `*.up.railway.app` default, if you want `api.yourdomain.com` — Railway's Networking settings support custom domains.
- **Confirm with Anthropic** that your account's usage policy covers reselling metered access through your own credit system, as flagged in `ARCHITECTURE.md` §1 — this is worth doing before real money changes hands, not after.
- **Build the five remaining AI feature prompts properly** — I wrote working routes and reasonable starting system prompts for training plans, nutrition, sparring review, opponent analysis, and fight camp builder, but you should review and tune each prompt against your book's actual content the same careful way the AI Coach prompt was built.
